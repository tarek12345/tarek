import React,{useEffect} from 'react'
import "./Utilisateur.css";
import Button from '@mui/material/Button';

 import Layout from '../../layout/layout';
import axios from 'axios';
import { DataGrid } from '@mui/x-data-grid'
import ModalUsers from '../../components/Modal/ModalUsers';
const client = axios.create({
  baseURL: "https://reqres.in/api/users" 
});
export default function Utilisateur() {
    const columns = [
        { field: 'id', headerName: 'Id' },
        { field: 'avatar', headerName: 'Profil', width: 130},
        { field: 'first_name', headerName: 'First_name', width: 130 },
        { field: 'last_name', headerName: 'Last_name', width: 130},
       
      ]

const [User, setUser] = React.useState(null);
useEffect(() => {
  const fetchPost = async () => {
    try {
     let response = await client.get();
     let users = response.data.data
     setUser(users);
     console.log(users)
    } catch (error) {
      if(axios.isCancel(error)){
        console.log('Data fetching cancelled');
      }else{
       // Handle error
      }
    }
  };
  fetchPost();

}, []);


  if (!User) return null;
  return (
 <Layout>
     <div className='row  titre-page'>
       <div className="col-xl-6">
        <h1 className='titre-page-1'>Listes Utilisateurs </h1> 
        </div>
        <div className="col-xl-6">
        <ModalUsers/>
        </div>
    <div style={{ height: 371, width: '100%' }}>
      <DataGrid
        rows={User}
        columns={columns}
        pageSize={5}
      />
    </div>
 </div>
 </Layout>
  )
}