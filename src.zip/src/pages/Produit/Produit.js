import React from 'react'
import Layout from '../../layout/layout';
import "./Produit.css";
export default function Produit() {
  return (
    <Layout>
    <div className='titre-page'>
    <h1 className='titre-page-1'>Listes des Produites </h1> 
    </div>
    </Layout>
  )
}



