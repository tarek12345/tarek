import React from 'react'
import Layout from '../../layout/layout';
import "./Dashbord.css"
export default function Dashbord() {
  return (
    <Layout>
    <div className='col-xl-9 titre-page'>
    <h1 className='titre-page-1'>Accueil </h1> 
    </div>
    </Layout>
    
  )
}
