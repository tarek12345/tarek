import React from 'react'
import Layout from '../../layout/layout';
import "./Facture.css";
export default function Facture() {
  return (
    <Layout>
    <div className='titre-page'>
     <h1 className='titre-page-1'>Listes des Factures </h1> 
    </div>
    </Layout>
  )
}