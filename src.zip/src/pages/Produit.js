import React from 'react'
import Sidebar from '../components/Sidebar'
export default function Produit() {
  return (
    <div className='row'>
    <div className='col-xl-3'>
        <Sidebar/>
    </div>
     <div className='col-xl-9'>
     Produit
 </div>
 </div>
  )
}



