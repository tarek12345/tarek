import React,{ useState }  from 'react'
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Navigate,useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import cafe from '../assets/cafe.webp'
function LoginForm() {
  const navigate=useNavigate();
    const [details,setDetails] =useState({code:""});
    const submitHandler =  e => {
        e.preventDefault();
      console.log(details)
      if(details.code =="admin"){
        toast.success('🦄 Wow so easy!', {
          position: "bottom-right",
          autoClose: 8000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          });
        navigate('/Dashbord');

      }else{
        toast.error("Login incorrect!", {
          position: "bottom-right",
          autoClose: 8000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          })
      }

      
    }
  return (
    <div className="sestion-login "style={{ 
      backgroundImage: `url(${cafe})` 
    }}>
      <div className="row">
             <div className="col-xl-12 ">
             <div className="sestion-login-1 ">
             <h2>Login</h2>

             <Stack 
      component="form"
      sx={{
        '& > :not(style)': { m: 1, width: '25ch' },
      }}
      noValidate
      autoComplete="off"
    >

         <TextField
          id="standard-password-input"
          label="Code"
          type="password"
          name="code"
          autoComplete="current-password"
          variant="standard"
          onChange={ e => setDetails({...details, code:e.target.value})} value= {details.code}
 />
  
      <Button   onClick={(e) => submitHandler(e, "clicked")}  variant="contained">Conneter</Button>

    </Stack>
    </div>
             </div>
    
     </div>
     <ToastContainer />
     </div>

  )
}

export default LoginForm