import React,{useState } from 'react'
import axios from 'axios';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { Box } from '@mui/system';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import IconButton from '@mui/material/IconButton';
import Input from '@mui/material/Input';
import FilledInput from '@mui/material/FilledInput';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import FormHelperText from '@mui/material/FormHelperText';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
export default function FormRegister() {
  const [password, setPassword] = useState({
    showPassword: false,
    password:''
})
  const [nom, setNom] = useState('')
  const [salaire, setSalaire] = useState('')
  const [role, setRole] = useState('')
  
  const handleChangeNom = (event) => {
    setNom(event.target.value);
  };
 
  const handleChangePassword = (prop) => (event) => {
    setPassword({ ...password, [prop]: event.target.value });
  };

  const handleClickShowPassword = () => {
    setPassword({
      ...password,
      showPassword: !password.showPassword,
    });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  const handleChangeSalaire = (event) => {
    setSalaire(event.target.value);
  };
  const cheklist=[
    {id:'gerant', value:'Gerant'},
    {id:'serveur', value:'Serveur'}
   ];
  const handleChangeRole =   (event) => {
    setRole(event.target.value);
  };


  const onSubmit = async (e) => {
    e.preventDefault()
    const users = {nom: nom,password:password,salaire:salaire,role:role }
    console.log('qdqsdqdqs',users)
    try {
      const res = await axios.post("https://reqres.in/api/users" ,users)
      console.log(res.data)
    } catch (e) {
      alert(e)
    }
  }
  const reset =  (event) =>  {
    setSalaire(event.target.value);
    setNom(event.target.value);
    setPassword(event.target.value);
    setRole(event.target.value);

  };

  return (
    <div>    
     <Stack 
      component="form"
      sx={{
        '& > :not(style)': { m: 1, width: '25ch' },
      }}
      Validate
      autoComplete="off"
    >
        <TextField
     
          type="Text"
          required
        id="standard-basic"
        variant="standard"
        label="Nom"
        value={nom}
        onChange={handleChangeNom}
      />

<FormControl sx={{ m: 1, width: '25ch' }} variant="standard">
          <InputLabel htmlFor="standard-adornment-password">Password</InputLabel>
          <Input
          required
            id="standard-adornment-password"
            type={password.showPassword ? 'text' : 'password'}
            value={password.password}
            onChange={handleChangePassword('password')}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                >
                  {password.showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>
             <FormControl fullWidth sx={{ sm: 1 }} variant="standard">
          <InputLabel htmlFor="standard-adornment-amount">Salaire</InputLabel>
          <Input
          required
            id="standard-adornment-amount"
            value={salaire}
            onChange={handleChangeSalaire}
            startAdornment={<InputAdornment position="start">TND</InputAdornment>}
          />
        </FormControl>
       
        <FormControl  variant="standard" sx={{ m: 1, minWidth: 120 }}>
        <InputLabel id="demo-simple-select-standard-label">Role</InputLabel>
        <Select 
        required
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={role}
          onChange={handleChangeRole}
          label="Role"
        >
          {cheklist.map((list) => (
              <MenuItem value={list.id}>{list.value}</MenuItem>
            ))}
      
        
        </Select>
        
      </FormControl>
    </Stack>
         <Box>
         <Button  className="containred"  onClick={onSubmit} >Enregistrer</Button>
         <Button   className="containred"  onClick={reset}>Annuler</Button>
         </Box> 
      {/* <form onSubmit={onSubmit}>
        <div className="mb-2 mt-3">
          <input
          required
            type="Text"
            placeholder="Nom"
            className="form-control"
            onChange={handleChangeNom}
            value={nom}
          />
            <input
          required
            type="password"
            placeholder="Login"
            className="form-control"
            onChange={handleChangePassword}
            value={password}
          />
             <input
             required
            type="number"
            placeholder="Salaire"
            className="form-control"
            onChange={handleChangeSalaire}
            value={salaire}
          />
        </div>
        <button type="submit" className="btn btn-success">
        Créer
        </button>
        <button onClick={reset} type="submit" className="btn btn-danger">
          Annuler
        </button>
      </form> */}
    </div>
    
  );
}