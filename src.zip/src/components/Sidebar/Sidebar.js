import React from 'react'
import HomeIcon from '@mui/icons-material/Home';
import ProductionQuantityLimitsIcon from '@mui/icons-material/ProductionQuantityLimits';
import ArticleIcon from '@mui/icons-material/Article';
import logo from '../../assets/logo-cafe.png';

import { NavLink } from "react-router-dom";
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import { Navigate,useNavigate } from "react-router-dom";
import "./sidebar.css";
function Sidebar() {
  const navigate=useNavigate();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
    navigate('/');
  };

  return (
    <div className='Sidebar' >
    
        <Button
        id="basic-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
      >
         <img src={logo} className='logo'/>
      </Button>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
      >
        <MenuItem onClick={handleClose}>Déconnecter</MenuItem>
      </Menu>
        <ul className='SidebarList'>
          <li className='rows'>
          <NavLink id='title' to="/Dashbord"  className={({ isActive }) => 
                      (isActive ? "active" : "not-active-class")}> <HomeIcon/> Dashbord</NavLink>
          </li>
          <li className='rows'>
          <NavLink id='title' to="/Utilisateur"  className={({ isActive }) => 
                      (isActive ? "active" : "not-active-class")}> <PersonOutlineIcon/> Utilisateur</NavLink>
          </li>
          <li className='rows'>
          <NavLink  id='title' to="/Produit"  className={({ isActive }) => 
                      (isActive ? "active" : "not-active-class")}> <ProductionQuantityLimitsIcon/> Produit</NavLink>
          </li>
          <li className='rows'>
          <NavLink  id='title' to="/Facture"  className={({ isActive }) => 
                      (isActive ? "active" : "not-active-class")}><ArticleIcon/> Facture</NavLink>
          </li>
       
          </ul>
         
        </div>
     
  )

}
export default Sidebar