import React,{props} from 'react'
import Sidebar from '../components/Sidebar/Sidebar';
import "./layout.css";
export default function layout(props) {
  return (
  
        <div className=' row Layout'>
              <div className="col-xl-3">
            <Sidebar />
            </div>
            <div className="col-xl-9 layoutContainer">
              
                <main>{props.children}</main>
            </div>
        </div>
    )
  
}

