import React,{ useState ,component} from "react";
import LoginForm from "./pages/LoginForm";
import Produit from "./pages/Produit/Produit" 
import Utilisateur from "./pages/Utilisateur/Utilisateur";
import Dashbord from "./pages/Dashbord/Dashbord";
import Facture from "./pages/Facture/Facture" ;
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  Outlet
} from "react-router-dom";
function App() {


  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/">
            <Route index element={<LoginForm />} />
            <Route path="Dashbord" element={<Dashbord />} />
            <Route path="Utilisateur" element={<Utilisateur />} />
            <Route path="Produit" element={<Produit />} />
            <Route path="Facture" element={<Facture />} />
          </Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
